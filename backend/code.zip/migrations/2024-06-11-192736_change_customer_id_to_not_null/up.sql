-- Your SQL goes here
ALTER TABLE repair_requests ALTER COLUMN customer_id SET NOT NULL;

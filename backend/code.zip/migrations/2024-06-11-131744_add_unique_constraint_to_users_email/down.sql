ALTER TABLE users
DROP CONSTRAINT unique_email;


-- down.sql
DROP TABLE users;
